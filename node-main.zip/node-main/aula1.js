var http = require('http');
http.createServer(function(req, res){
    res.write('olha se vc nao me ama \n');
    res.end('Olá meus amigos de salvador aqui qm fala eh o manuel gome o caneta azulll');
}).listen(3000);
